# CyberKavach APK (English, Hindi, Tamil, Telugu, Kannada, Malayalam, Bengali, Marathi)

## Option A – build in the cloud (no local setup)
1. Create a GitHub repo and upload everything in this folder (keep `.github/`).
2. Open the Actions tab, run "Build APK", then download `cyberkavach-apk`.

## Option B – build locally (Flutter stable + Android SDK installed)
    bash setup.sh
    cd app && flutter build apk --release
APK: app/build/app/outputs/flutter-apk/app-release.apk

## Install
Copy the APK to an Android phone and allow "install unknown apps". Play Protect may warn because the app is unsigned by the Play Store.

## Notes
- Real SMS auto-read needs the SMS permission (asked on first "Auto-protect SMS" toggle).
- Play Store publishing restricts SMS permissions; sideloading is fine for demos.
- Have native speakers review lib/l10n.dart before public release.
- Add a language: add a row to `langs`, `ttsCode`, and a 22-string list in `_v`.
