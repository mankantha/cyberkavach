package com.cyberkavach.cyberkavach

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import io.flutter.plugin.common.EventChannel

class SmsReceiver : BroadcastReceiver() {
    companion object { var sink: EventChannel.EventSink? = null }

    override fun onReceive(ctx: Context, i: Intent) {
        val p = Telephony.Sms.Intents.getMessagesFromIntent(i)
        if (p.isNullOrEmpty()) return
        val from = p[0].originatingAddress ?: "?"
        val body = p.joinToString("") { it.messageBody ?: "" }
        val s = sink
        if (s != null) { s.success(mapOf("sender" to from, "body" to body)); return }
        // App closed: quick native check and notify
        if (Regex("(?i)https?://|bit\\.ly|otp|kyc|block|lottery|prize").containsMatchIn(body)) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26)
                nm.createNotificationChannel(NotificationChannel("ck", "CyberKavach", NotificationManager.IMPORTANCE_HIGH))
            val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            val pi = PendingIntent.getActivity(ctx, 0, launch, PendingIntent.FLAG_IMMUTABLE)
            val n = NotificationCompat.Builder(ctx, "ck")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("⚠️ CyberKavach")
                .setContentText("Possible scam SMS from $from – tap to check")
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(1, n)
        }
    }
}
