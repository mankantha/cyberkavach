package com.cyberkavach.cyberkavach

import android.telephony.SmsManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(e: FlutterEngine) {
        super.configureFlutterEngine(e)
        val m = e.dartExecutor.binaryMessenger
        EventChannel(m, "cyberkavach/sms").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(a: Any?, s: EventChannel.EventSink?) { SmsReceiver.sink = s }
            override fun onCancel(a: Any?) { SmsReceiver.sink = null }
        })
        MethodChannel(m, "cyberkavach/native").setMethodCallHandler { c, r ->
            if (c.method == "sendSms") {
                try {
                    val sm = getSystemService(SmsManager::class.java)
                    val parts = sm.divideMessage(c.argument<String>("text"))
                    sm.sendMultipartTextMessage(c.argument<String>("to"), null, parts, null, null)
                    r.success(true)
                } catch (x: Exception) { r.error("sms", x.message, null) }
            } else r.notImplemented()
        }
    }
}
