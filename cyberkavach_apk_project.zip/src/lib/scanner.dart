class Scan { final int score; final List<int> flags; Scan(this.score, this.flags); }

// Each rule: [pattern, weight, flag index in l10n]. Keywords cover 8 languages.
final _rules = <List<dynamic>>[
  [RegExp(r'otp|\bpin\b|cvv|password|ओटीपी|ஓடிபி|ఓటీపీ|ಒಟಿಪಿ|ഒടിപി|ওটিপি', caseSensitive: false), 25, 14],
  [RegExp(r'urgent|immediately|expires? today|within \d+ ?(hours?|mins?)|तुरंत|अभी|जल्दी|உடனே|அவசர|తక్షణ|తొందర|ತಕ್ಷಣ|ಆತುರ|ഉടൻ|এখনই|তাড়াতাড়ি|त्वरित|घाई', caseSensitive: false), 15, 15],
  [RegExp(r'block(ed)?|suspend|deactivat|freeze|बंद|ब्लॉक|முடக்க|బ్లాక్|ಬಂದ್|ബ്ലോക്ക്|ব্লক|বন্ধ', caseSensitive: false), 18, 16],
  [RegExp(r'\bkyc\b|verify your (account|identity)|केवाईसी', caseSensitive: false), 18, 17],
  [RegExp(r'\bwon\b|lottery|lucky draw|prize|reward|इनाम|लॉटरी|பரிசு|லாட்டரி|బహుమతి|లాటరీ|ಬಹುಮಾನ|ಲಾಟರಿ|സമ്മാനം|ലോട്ടറി|পুরস্কার|লটারি|बक्षीस', caseSensitive: false), 20, 18],
  [RegExp(r'processing fee|registration fee|pay rs|send rs|शुल्क|கட்டணம்|రుసుము|ಶುಲ್ಕ|ഫീസ്|ফি', caseSensitive: false), 22, 19],
];
const _brands = ['sbi','hdfc','icici','axis','paytm','phonepe','paypal','amazon','irctc','kotak','pnb'];
final _urlRe = RegExp(r'https?://\S+|\b(?:bit\.ly|tinyurl\.com|cutt\.ly|rb\.gy|wa\.me)/\S+', caseSensitive: false);

Scan analyze(String t) {
  var s = 0; final f = <int>{};
  for (final r in _rules) {
    if ((r[0] as RegExp).hasMatch(t)) { s += r[1] as int; f.add(r[2] as int); }
  }
  for (final m in _urlRe.allMatches(t)) {
    final u = m.group(0)!; var p = 8; f.add(20);
    final h = (Uri.tryParse(u.startsWith('http') ? u : 'http://$u')?.host ?? '').toLowerCase();
    if (RegExp(r'\.(xyz|top|tk|click|link|icu|buzz|work)$').hasMatch(h)) { p += 15; f.add(21); }
    if (RegExp(r'^(bit\.ly|tinyurl\.com|cutt\.ly|rb\.gy)$').hasMatch(h)) p += 10;
    for (final b in _brands) {
      if (h.contains(b) && !RegExp('(^|\\.)$b\\.(com|co\\.in|in)\$').hasMatch(h)) { p += 20; f.add(21); }
    }
    if (u.startsWith('http://')) p += 5;
    s += p;
  }
  return Scan(s.clamp(0, 100), f.toList());
}
