import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'l10n.dart';
import 'scanner.dart';

void main() => runApp(const App());

class App extends StatefulWidget {
  const App({super.key});
  @override State<App> createState() => _AppS();
}

class _AppS extends State<App> {
  String? lang; bool ready = false;
  @override void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => setState(() { lang = p.getString('lang'); ready = true; }));
  }
  Future<void> setLang(String? l) async {
    final p = await SharedPreferences.getInstance();
    if (l == null) { await p.remove('lang'); } else { await p.setString('lang', l); }
    setState(() => lang = l);
  }
  @override Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF1D4ED8)),
    home: !ready ? const Scaffold(body: Center(child: CircularProgressIndicator()))
        : lang == null ? Picker(onPick: setLang) : Home(lang: lang!, onChangeLang: () => setLang(null)));
}

class Picker extends StatelessWidget {
  final void Function(String) onPick;
  const Picker({super.key, required this.onPick});
  @override Widget build(BuildContext c) => Scaffold(body: SafeArea(child: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(children: [
      const Text('🛡️', style: TextStyle(fontSize: 56)),
      const SizedBox(height: 8),
      const Text('Choose your language · भाषा चुनें · மொழியைத் தேர்ந்தெடுக்கவும்',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
      const SizedBox(height: 16),
      Expanded(child: GridView.count(crossAxisCount: 2, childAspectRatio: 2.2, mainAxisSpacing: 12, crossAxisSpacing: 12,
        children: langs.entries.map((e) => FilledButton.tonal(
          onPressed: () => onPick(e.key), child: Text(e.value, style: const TextStyle(fontSize: 22)))).toList())),
    ]))));
}

class Home extends StatefulWidget {
  final String lang; final VoidCallback onChangeLang;
  const Home({super.key, required this.lang, required this.onChangeLang});
  @override State<Home> createState() => _HomeS();
}

class _HomeS extends State<Home> {
  final tc = TextEditingController(), gc = TextEditingController();
  final tts = FlutterTts();
  static const sms = EventChannel('cyberkavach/sms');
  static const nat = MethodChannel('cyberkavach/native');
  Scan? res; bool live = false; StreamSubscription? sub;
  String t(int i) => tr(widget.lang, i);

  @override void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => gc.text = p.getString('g') ?? '');
  }

  Future<void> toggle(bool v) async {
    if (v) {
      final st = await [Permission.sms, Permission.notification].request();
      if (st[Permission.sms]?.isGranted ?? false) {
        sub = sms.receiveBroadcastStream().listen(onSms);
        setState(() => live = true);
      }
    } else { await sub?.cancel(); setState(() => live = false); }
  }

  void onSms(dynamic e) {
    final m = Map<String, dynamic>.from(e);
    final r = analyze(m['body'] as String);
    setState(() { res = r; tc.text = m['body'] as String; });
    if (r.score >= 60) {
      final n = gc.text.trim();
      if (n.isNotEmpty) {
        nat.invokeMethod('sendSms', {'to': n,
          'text': 'CyberKavach alert: a scam SMS reached my phone from ${m['sender']}. Please call me. Do not click any link.'});
      }
      speak(r);
    }
  }

  Future<void> speak(Scan r) async {
    try {
      await tts.setLanguage(ttsCode[widget.lang]!);
      await tts.speak('${t(r.score >= 60 ? 7 : r.score >= 30 ? 6 : 5)}. ${r.score >= 30 ? t(9) : ''}');
    } catch (_) {}
  }

  @override Widget build(BuildContext c) {
    final r = res;
    final k = r == null ? 0 : r.score >= 60 ? 2 : r.score >= 30 ? 1 : 0;
    const col = [Colors.green, Colors.orange, Colors.red];
    return Scaffold(
      appBar: AppBar(title: Text('🛡️ ${t(0)}'),
        actions: [IconButton(icon: const Icon(Icons.language), onPressed: widget.onChangeLang)]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SwitchListTile(title: Text(t(11), style: const TextStyle(fontSize: 18)), value: live, onChanged: toggle),
        Row(children: [
          Expanded(child: TextField(controller: gc, keyboardType: TextInputType.phone,
            decoration: InputDecoration(labelText: t(12), border: const OutlineInputBorder()))),
          const SizedBox(width: 8),
          FilledButton(onPressed: () async => (await SharedPreferences.getInstance()).setString('g', gc.text), child: Text(t(13))),
        ]),
        const SizedBox(height: 16),
        TextField(controller: tc, maxLines: 5, decoration: InputDecoration(labelText: t(3), border: const OutlineInputBorder())),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => setState(() => res = analyze(tc.text)), icon: const Icon(Icons.search),
          label: Text(t(4), style: const TextStyle(fontSize: 20)),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56))),
        if (r != null) ...[
          const SizedBox(height: 16),
          Card(color: col[k].withOpacity(.12), child: Padding(padding: const EdgeInsets.all(16), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon([Icons.check_circle, Icons.warning, Icons.dangerous][k], color: col[k], size: 48),
                const SizedBox(width: 12),
                Expanded(child: Text(t(5 + k), style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: col[k]))),
              ]),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: r.score / 100, color: col[k], minHeight: 10),
              if (r.flags.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(t(8), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                ...r.flags.map((i) => ListTile(dense: true, leading: const Icon(Icons.error_outline),
                    title: Text(t(i), style: const TextStyle(fontSize: 17)))),
                Text(t(9), style: const TextStyle(fontSize: 17)),
              ],
              const SizedBox(height: 8),
              OutlinedButton.icon(onPressed: () => speak(r), icon: const Icon(Icons.volume_up), label: Text(t(10))),
            ]))),
        ],
      ]),
    );
  }
}
