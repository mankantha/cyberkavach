#!/usr/bin/env bash
# Generates the Android project and applies CyberKavach sources.
set -e
flutter create --org com.cyberkavach --project-name cyberkavach --platforms android app
cp src/pubspec.yaml app/pubspec.yaml
rm -rf app/lib app/test
cp -r src/lib app/lib
K=app/android/app/src/main/kotlin/com/cyberkavach/cyberkavach
mkdir -p "$K"
cp overrides/kotlin/*.kt "$K"/
cp overrides/AndroidManifest.xml app/android/app/src/main/AndroidManifest.xml
cd app && flutter pub get
